# ----------------------------------------------------------------------------
# MlengelaDP11
# Programmer: Daudi Mlengela
# Email: dmlengela@cn.edu
# Purpose: demonstrates how to connect to a database and use its contents
# with Geo Points
# ----------------------------------------------------------------------------

from sqlite3 import Error
import sqlite3

def create_connection(db_file):

   conn = None

   try:

      conn = sqlite3.connect(db_file)
      cur  = conn.cursor()

      sql = "drop table if exists points"
      print("Executing: [" + sql + "]")
      cur.execute(sql)

      sql = "create table points ( latitude real, longitude real, description text )"
      print("Executing: [" + sql + "]")
      cur.execute(sql)

      list = [
         [ 35.0714, -106.6289, 'Main Campus' ],
         [ 35.0998, -104.0639, 'Montoya' ],
         [ 35.2328, -106.6630, 'Rio Rancho' ],
         [ 35.0856, -106.6493, 'STEMULUS Center' ],
         [ 35.1836, -106.5939, 'ATC' ]
      ]

      for entry in list:

         sql = "insert into points(latitude, longitude, description) " + \
             "values({0}, {1}, '{2}')".format(entry[0], entry[1], entry[2])

         print("Executing: [" + sql + "]")
         cur.execute(sql)

      conn.commit()

      sql = "select * from points"

      print("Executing: [" + sql + "]")
      cur.execute("select * from points")

      rows = cur.fetchall()

      for row in rows:
         print(row)

   except Error as e:
      print(e)

   finally:
      if conn:
         conn.close()

if __name__ == '__main__':
    create_connection(r"points.db")
